// Creates the Render-ready package: a zip with 18 files at its top level (no folders at all), so that
// "select all → drag into GitHub → Upload files" puts every file in the repository root.
// The site is pre-built; on Render `npm ci && npm run build` only downloads Stockfish 19 and assembles dist/.
//   node scripts/package-render.mjs   →  release/sf19-coach-render.zip
import { execSync } from 'node:child_process';
import { copyFileSync, mkdirSync, readdirSync, rmSync, writeFileSync, readFileSync, statSync } from 'node:fs';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = join(dirname(fileURLToPath(import.meta.url)), '..');
const out = join(root, 'release');
const pkg = join(out, 'sf19-coach-render');
rmSync(out, { recursive: true, force: true });
mkdirSync(pkg, { recursive: true });

execSync('node scripts/build.mjs --no-engine', { cwd: root, stdio: 'inherit' });
for (const f of readdirSync(join(root, 'dist'))) {
  if (f === 'engine') continue;
  copyFileSync(join(root, 'dist', f), join(pkg, f));
}
for (const f of ['render.yaml', 'README.md', 'package.json', 'package-lock.json', 'build-site.mjs']) copyFileSync(join(root, 'deploy', f), join(pkg, f));
copyFileSync(join(root, 'LICENSE'), join(pkg, 'LICENSE'));

// Full source code (GPLv3) as a single file, also served by the app (Help → source.zip).
execSync(`zip -qr -9 "${join(pkg, 'source.zip')}" . -x "node_modules/*" "dist/*" "release/*" "build-tmp/*" "*/__pycache__/*" ".git/*"`, { cwd: root });

execSync('zip -q -9 ../sf19-coach-render.zip *', { cwd: pkg }); // files only, no parent folder inside the zip
const files = readdirSync(pkg);
console.log(`✔ release/sf19-coach-render.zip — ${files.length} files (no folders):`);
for (const f of files) console.log(`  ${f.padEnd(26)} ${(statSync(join(pkg, f)).size / 1024).toFixed(0)} KiB`);

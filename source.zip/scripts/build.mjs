// Build: bundles the app with esbuild into a FLAT dist/ folder (no sub-folders except engine/),
// and — if the `stockfish` npm package is installed — copies Stockfish 19 (WASM) into dist/engine/.
//   node scripts/build.mjs            production build (+ engine if node_modules/stockfish exists)
//   node scripts/build.mjs --dev      unminified, with source maps
//   node scripts/build.mjs --no-engine  skip copying the engine (the host downloads it at deploy time)
import { build } from 'esbuild';
import { readFileSync, writeFileSync, mkdirSync, rmSync, copyFileSync, readdirSync, statSync, existsSync } from 'node:fs';
import { join, dirname } from 'node:path';
import { createHash } from 'node:crypto';
import { fileURLToPath } from 'node:url';

const root = join(dirname(fileURLToPath(import.meta.url)), '..');
const src = join(root, 'src');
const dist = join(root, 'dist');
const nm = join(root, 'node_modules');
const dev = process.argv.includes('--dev');
const noEngine = process.argv.includes('--no-engine');

rmSync(dist, { recursive: true, force: true });
mkdirSync(dist, { recursive: true });

// 1) Piece sprites (cburnett, from chessground) as CSS classes for figurines, captured pieces, editor.
const cburnett = readFileSync(join(nm, '@lichess-org/chessground/assets/chessground.cburnett.css'), 'utf8');
const pieceRules = [];
for (const m of cburnett.matchAll(/\.cg-wrap piece\.(\w+)\.(white|black)\s*\{\s*background-image:\s*url\('([^']+)'\);?\s*\}/g)) {
  const [, role, color, uri] = m;
  pieceRules.push(`.pc-${role}-${color}{background-image:url('${uri}')}`);
  if (color === 'white') pieceRules.push(`.fig-${role}{background-image:url('${uri}')}`);
}
if (pieceRules.length < 18) throw new Error('could not extract piece images');
mkdirSync(join(root, 'build-tmp'), { recursive: true });
writeFileSync(join(root, 'build-tmp/pieces.css'), `/* generated from chessground cburnett (GPL) */\n${pieceRules.join('\n')}\n`);

// 2) JS + CSS bundles → dist/app.js, dist/app.css
const common = { bundle: true, minify: !dev, sourcemap: dev, target: ['es2020', 'chrome90', 'firefox90', 'safari15'], logLevel: 'warning', legalComments: 'eof' };
await build({
  ...common,
  entryPoints: { app: join(src, 'js/main.jsx') },
  outdir: dist,
  format: 'esm',
  jsx: 'automatic',
  jsxImportSource: 'preact',
  define: { 'process.env.NODE_ENV': dev ? '"development"' : '"production"' },
});
await build({
  ...common,
  entryPoints: { app: join(src, 'css/app.css') },
  outdir: dist,
  loader: { '.svg': 'dataurl', '.png': 'dataurl' },
});
rmSync(join(root, 'build-tmp'), { recursive: true, force: true });

// 3) Static files (flat)
for (const name of readdirSync(join(src, 'static'))) copyFileSync(join(src, 'static', name), join(dist, name));

// 4) Version (content hash) → cache-busting query strings + service-worker cache name
const version = createHash('sha256')
  .update(readFileSync(join(dist, 'app.js'))).update(readFileSync(join(dist, 'app.css'))).update(readFileSync(join(src, 'sw.js')))
  .digest('hex').slice(0, 10);
const appJs = `app.js?v=${version}`;
const appCss = `app.css?v=${version}`;
let html = readFileSync(join(src, 'index.html'), 'utf8');
html = html.replace('%APP_JS%', appJs).replace('%APP_CSS%', appCss).replace(/%VERSION%/g, version);
writeFileSync(join(dist, 'index.html'), html);
const precache = ['./', appJs, appCss, 'openings.json', 'manifest.webmanifest', 'icon-192.png', 'icon-512.png', 'favicon.svg'];
let sw = readFileSync(join(src, 'sw.js'), 'utf8');
sw = sw.replace('__VERSION__', version).replace('__PRECACHE__', JSON.stringify(precache));
writeFileSync(join(dist, 'sw.js'), sw);

// 5) Stockfish 19 engine files (from the `stockfish` npm package), unless the host fetches them itself
const engines = ['stockfish-19', 'stockfish-19-single', 'stockfish-19-lite', 'stockfish-19-lite-single'];
const sfBin = join(nm, 'stockfish/bin');
if (!noEngine && existsSync(sfBin)) {
  mkdirSync(join(dist, 'engine'), { recursive: true });
  for (const e of engines) for (const ext of ['.js', '.wasm']) copyFileSync(join(sfBin, e + ext), join(dist, 'engine', e + ext));
  copyFileSync(join(nm, 'stockfish/Copying.txt'), join(dist, 'engine/COPYING.txt'));
} else if (!noEngine) {
  console.warn('! node_modules/stockfish not found: dist/engine/ was not created (run `npm install`).');
}

// Report
const kb = f => `${(statSync(join(dist, f)).size / 1024).toFixed(0)} KiB`;
console.log(`✔ built ${dev ? '(dev) ' : ''}v${version}`);
console.log(`  app.js ${kb('app.js')} · app.css ${kb('app.css')} · ${readdirSync(dist).length} entries in dist/`);
if (existsSync(join(dist, 'engine'))) for (const e of engines) console.log(`  engine/${e}.wasm  ${(statSync(join(dist, `engine/${e}.wasm`)).size / 1048576).toFixed(1)} MiB`);
